<?php 
session_start();
include_once("../crudop/crud.php");
$crud = new Crud();
$tableName = 'tbl_interactions';

extract($_POST);

$cust_id  = isset($cust_id) ? $cust_id :'';
$int_type = isset($int_type) ? $int_type : '';
$product  = isset($product) ? $product : '-';
$date     = isset($date) ? $date : '';
$hdn_id   = isset($hdn_id) ? $hdn_id : '';

$randomId = uniqid(substr(0, 10));

/*--------------------------------------------------------------
                        Display Data
--------------------------------------------------------------*/
if(isset($_POST['action']) && $_POST['action'] == 'show'){

    $Users_Qry = "SELECT INTR.*, USR.NAME AS NAME FROM ".$tableName." as INTR LEFT JOIN tbl_users as USR on USR.ID = INTR.CUST_ID";
    $Users_Data = $crud->getData($Users_Qry);

    $response = array(
        "draw" => 1,
        "recordsTotal" => count($Users_Data),
        "data" => $Users_Data
    );

    echo json_encode($response);
}

/*--------------------------------------------------------------
                        Save Data
--------------------------------------------------------------*/
if(isset($_POST['action']) && $_POST['action'] == 'save'){

    $Users_Qry = "INSERT INTO ".$tableName." SET CUST_ID = '".$cust_id."', INT_TYPE = '".$int_type."', PRODUCT = '".$product."', DATE = '".$date."', RANDOM_ID = '".$randomId."'";
    $Users_Data = $crud->execute($Users_Qry);

    if ($Users_Data) {
        echo 'true';
    } else {
        echo 'false';
    }
}

/*--------------------------------------------------------------
                        Delete Data
--------------------------------------------------------------*/
if(isset($_POST['action']) && $_POST['action'] == 'delete'){
    $id = $_POST['id'];

    $Del_Users = "DELETE FROM ".$tableName." WHERE ID = '".$id."'";
    $Del_Data = $crud->execute($Del_Users);

    if ($Del_Data) {
        echo 'true';
    } else {
        echo 'false';
    }
}

/*--------------------------------------------------------------
                        Update Data
--------------------------------------------------------------*/
if(isset($_POST['action']) && $_POST['action'] == 'update'){
    
    $Users_Update = "UPDATE ".$tableName." SET CUST_ID = '".$cust_id."', INT_TYPE = '".$int_type."', PRODUCT = '".$product."', DATE = '".$date."' WHERE RANDOM_ID = '".$hdn_id."'";
    $Update_Data = $crud->execute($Users_Update);

    if ($Update_Data) {
        echo 'true';
    } else {
        echo 'false';
    }
}

/*--------------------------------------------------------------
                    Generate Products Dropdown
--------------------------------------------------------------*/
if(isset($_POST['action']) && $_POST['action'] == 'customerProducts'){
    $Users_Qry = "SELECT * FROM tbl_purchases WHERE CUST_ID = '".$cust_id."'";
    $Users_Data = $crud->getData($Users_Qry);

    $response = array(
        "draw" => 1,
        "recordsTotal" => count($Users_Data),
        "data" => $Users_Data
    );

    echo json_encode($response);
}

?>