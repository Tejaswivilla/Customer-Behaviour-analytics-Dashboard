<?php 
session_start();
include_once("../crudop/crud.php");
$crud = new Crud();
$tableName = 'tbl_users';

extract($_POST);

$name      = isset($name) ? $name :'';
$phone     = isset($phone) ? $phone : '';
$address   = isset($address) ? $address : '';
$old_image = isset($old_image) ? $old_image : '';
$hdn_id    = isset($hdn_id) ? $hdn_id : '';

$randomId  = uniqid(substr(0, 10));
$image = '';
$image_targetDir = "../uploads/";

if(isset($_FILES['image'])){

    $imagefileName = basename($_FILES["image"]["name"]);
    $targetimageFilePath = $image_targetDir.$randomId. "image".$imagefileName;
    if(move_uploaded_file($_FILES["image"]["tmp_name"], $targetimageFilePath)){
        $image = $targetimageFilePath;
        if ($_POST['action'] == 'update') {
            unlink($old_image);
        }
    }
} else {
    $image = $old_image;
}

/*--------------------------------------------------------------
                        Display Data
--------------------------------------------------------------*/
if(isset($_POST['action']) && $_POST['action'] == 'show'){

    $Users_Qry = "SELECT 
    DISTINCT u.*,
    CASE
        -- New User: User ID exists in tbl_users but not in tbl_purchases
        WHEN p.CUST_ID IS NULL THEN 'RECENTLY ADDED CUSTOMER'

        -- High Value Customer: High total expenditure or high average price per transaction
        WHEN (
            (SELECT SUM(PRICE) FROM tbl_purchases WHERE CUST_ID = u.ID) > 10000 OR
            (SELECT AVG(PRICE) FROM tbl_purchases WHERE CUST_ID = u.ID) > 1000
        ) THEN 'HIGH VALUE CUSTOMER'

        -- New Customer: Only one recent purchase
        WHEN (
            (SELECT COUNT(*) FROM tbl_purchases WHERE CUST_ID = u.ID) = 1 AND
            p.DATE > DATE_SUB(NOW(), INTERVAL 30 DAY)
        ) THEN 'NEW CUSTOMER'
        
        -- Frequent Buyer: Many purchases over time
        WHEN (
            (SELECT COUNT(*) FROM tbl_purchases WHERE CUST_ID = u.ID) > 5 AND
            p.DATE > DATE_SUB(NOW(), INTERVAL 1 YEAR)
        ) THEN 'FREQUENT BUYER'

        -- Product Preference Buyer: Consistently buys the same product or within the same category
        WHEN (
            (SELECT COUNT(DISTINCT PRODUCT_CATG) FROM tbl_purchases WHERE CUST_ID = u.ID) = 1 OR
            (SELECT COUNT(DISTINCT PRODUCT) FROM tbl_purchases WHERE CUST_ID = u.ID) = 1
        ) THEN 'PRODUCT PREFERENCE BUYER'

        -- Default to 'UNCLASSIFIED' if none of the conditions match
        ELSE 'UNFREQUENT BUYER'
    END AS CUSTOMER_TYPE
FROM 
    tbl_users u
LEFT JOIN 
    tbl_purchases p 
ON 
    u.ID = p.CUST_ID;";
    $Users_Data = $crud->getData($Users_Qry);

    $response = array(
        "draw" => 1,
        "recordsTotal" => count($Users_Data),
        "data" => $Users_Data
    );

    echo json_encode($response);
}

/*--------------------------------------------------------------
                        Save Data
--------------------------------------------------------------*/
if(isset($_POST['action']) && $_POST['action'] == 'save'){

    $Users_Qry = "INSERT INTO ".$tableName." SET NAME = '".$name."', PHONE = '".$phone."', ADDRESS = '".$address."', IMAGE = '".$image."', RANDOM_ID = '".$randomId."'";
    $Users_Data = $crud->execute($Users_Qry);

    if ($Users_Data) {
        echo 'true';
    } else {
        echo 'false';
    }
}

/*--------------------------------------------------------------
                        Delete Data
--------------------------------------------------------------*/
if(isset($_POST['action']) && $_POST['action'] == 'delete'){
    $id = $_POST['id'];
    $image = $_POST['image'];

    $Del_Users = "DELETE FROM ".$tableName." WHERE ID = '".$id."'";
    $Del_User_data1 = "DELETE FROM tbl_purchases WHERE CUST_ID = '".$id."'";
    $Del_User_data2 = "DELETE FROM tbl_interactions WHERE CUST_ID = '".$id."'";

    $Del_Data = $crud->execute($Del_Users);
    $Del_Data1 = $crud->execute($Del_User_data1);
    $Del_Data2 = $crud->execute($Del_User_data2);

    if ($Del_Data && $Del_Data1 && $Del_Data2) {
        unlink($image);
        echo 'true';
    } else {
        echo 'false';
    }
}

/*--------------------------------------------------------------
                        Update Data
--------------------------------------------------------------*/
if(isset($_POST['action']) && $_POST['action'] == 'update'){
    
    $Users_Update = "UPDATE ".$tableName." SET NAME = '".$name."', PHONE = '".$phone."', ADDRESS = '".$address."', IMAGE = '".$image."' WHERE RANDOM_ID = '".$hdn_id."'";
    $Update_Data = $crud->execute($Users_Update);

    if ($Update_Data) {
        echo 'true';
    } else {
        echo 'false';
    }
}

?>