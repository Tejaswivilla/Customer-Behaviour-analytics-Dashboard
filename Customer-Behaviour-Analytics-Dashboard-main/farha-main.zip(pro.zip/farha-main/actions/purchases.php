<?php 
session_start();
include_once("../crudop/crud.php");
$crud = new Crud();
$tableName = 'tbl_purchases';

extract($_POST);

$cust_id       = isset($cust_id) ? $cust_id :'';
$product_catg  = isset($product_catg) ? $product_catg : '';
$product       = isset($product) ? $product : '';
$date          = isset($date) ? $date : '';
$price         = isset($price) ? $price : '';
$hdn_id        = isset($hdn_id) ? $hdn_id : '';

$randomId      = uniqid(substr(0, 10));

/*--------------------------------------------------------------
                        Display Data
--------------------------------------------------------------*/
if(isset($_POST['action']) && $_POST['action'] == 'show'){

    $Purchases_Qry = "SELECT PUR.*, USR.NAME as NAME FROM ".$tableName." as PUR LEFT JOIN tbl_users as USR ON PUR.CUST_ID = USR.ID";
    $Purchases_Data = $crud->getData($Purchases_Qry);

    $response = array(
        "draw" => 1,
        "recordsTotal" => count($Purchases_Data),
        "data" => $Purchases_Data
    );

    echo json_encode($response);
}

/*--------------------------------------------------------------
                        Save Data
--------------------------------------------------------------*/
if(isset($_POST['action']) && $_POST['action'] == 'save'){

    $Purchases_Qry = "INSERT INTO ".$tableName." SET CUST_ID = '".$cust_id."', PRODUCT_CATG = '".$product_catg."', PRODUCT = '".$product."', DATE = '".$date."', PRICE = '".$price."', RANDOM_ID = '".$randomId."'";
    $Purchases_Data = $crud->execute($Purchases_Qry);

    if ($Purchases_Data) {
        echo 'true';
    } else {
        echo 'false';
    }
}

/*--------------------------------------------------------------
                        Delete Data
--------------------------------------------------------------*/
if(isset($_POST['action']) && $_POST['action'] == 'delete'){

    $id = $_POST['id'];
    $Del_Purchase = "DELETE FROM ".$tableName." WHERE ID = '".$id."'";
    $Del_Data = $crud->execute($Del_Purchase);

    if ($Del_Data) {
        echo 'true';
    } else {
        echo 'false';
    }
}

/*--------------------------------------------------------------
                        Update Data
--------------------------------------------------------------*/
if(isset($_POST['action']) && $_POST['action'] == 'update'){

    $Updates_Purchases = "UPDATE ".$tableName." SET CUST_ID = '".$cust_id."', PRODUCT_CATG = '".$product_catg."', PRODUCT = '".$product."', DATE = '".$date."', PRICE = '".$price."' WHERE RANDOM_ID = '".$hdn_id."'";
    $Update_Data = $crud->execute($Updates_Purchases);

    if ($Update_Data) {
        echo 'true';
    } else {
        echo 'false';
    }
}

?>