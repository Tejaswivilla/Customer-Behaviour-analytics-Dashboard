$(function() {
  $("form[name='editUserForm']").validate({
   
    rules: {         
      name     : "required",
      phone    : "required",
      address  : "required",
    },

    messages: {         
      name     : "Please Enter Customer Name",
      phone    : "Please Enter Phone",
      address  : "Please Enter Address",
    },
    
    submitHandler: function(form) {
      
      let formdata = new FormData();
      let x = $('#editUserForm').serializeArray();
      $.each(x, function(i, field){
        formdata.append(field.name,field.value);
      });
      formdata.append('action' , 'update');  

      let image = $('#image')[0].files;

      if (image.length > 0){
        formdata.append('image', image[0]);
      }      
     
      $.ajax({
        type: "POST",
        url: "actions/userProfile.php",
        enctype: 'multipart/form-data',
        processData: false,
        contentType: false,
        cache: false,
        data: formdata,
        success: function (data) {
          if (data.trim() == 'true'){
            toastr.success('Updated Successfully...!');
            setTimeout(function (){
              location.href = "manageUserProfiles.php";
            },1000);
          }
          else{
            toastr.error('Data not Updated..!');
          }
        }
      });
    }
  });
});