$(function() {
  $("form[name='editInteractionsForm']").validate({
   
    rules: {         
      cust_id   : "required",
      int_type  : "required",
      product   : "required",
      date      : "required",
    },

    messages: {         
      cust_id   : "Please Select Customer Name",
      int_type  : "Please Select Interaction Type",
      product   : "Please Enter Product Name",
      date      : "Please Select Date",
    },
    
    submitHandler: function(form) {
      
      let formdata = new FormData();
      let x = $('#editInteractionsForm').serializeArray();
      $.each(x, function(i, field){
        formdata.append(field.name,field.value);
      });
      formdata.append('action' , 'update');       
     
      $.ajax({
        type: "POST",
        url: "actions/interactions.php",
        enctype: 'multipart/form-data',
        processData: false,
        contentType: false,
        cache: false,
        data: formdata,
        success: function (data) {
          if (data.trim() == 'true'){
            toastr.success('Updated Successfully...!');
            setTimeout(function (){
              location.href = "manageInteractions.php";
            },1000);
          }
          else{
            toastr.error('Data not Updated..!');
          }
        }
      });
    }
  });
});

function GenetateProduct(cust_id) {
  alert(cust_id);
  $('#productsDD').empty();
  $.ajax({
    type: "POST",
    url: "actions/interactions.php",
    data: { action: "customerProducts", cust_id: cust_id },
    success: function(data) {
      var prod_data = JSON.parse(data);
      var products = "<label>Product</label><select class='form-control form-select' name='product' id='product'><option value=''>-- Select Product --</option>";
      
      prod_data.data.forEach(function(item) {
        products += "<option value='" + item.PRODUCT + "'>" + item.PRODUCT + "</option>";
      });
      
      products += "<option value='OTHER'>Others</option></select>";
      $('#productsDD').html(products);
    }
  });
}

function FillProduct(InteractionType) {
  if (InteractionType == "V") {
    $("#product").val('OTHER');
  } else {
    $("#product").val('');
  }
}