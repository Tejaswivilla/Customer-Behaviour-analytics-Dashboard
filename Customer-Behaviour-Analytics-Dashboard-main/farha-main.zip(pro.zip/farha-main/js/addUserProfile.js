$(function() {
  $("form[name='addUserForm']").validate({
   
    rules: {         
      name    : "required",
      phone   : "required",
      address : "required",
      image   : "required",
    },

    messages: {         
      name    : "Please Enter Customer Name",
      phone   : "Please Enter Phone Number",
      address : "Please Enter Address",
      image   : "Please Choose Profile Image",
    },
    
    submitHandler: function(form) {

      let formdata = new FormData();
      let x = $('#addUserForm').serializeArray();
      $.each(x, function(i, field){
        formdata.append(field.name,field.value);
      });
      formdata.append('action' , 'save');
        
      let image = $('#image')[0].files;

      if (image.length > 0){
        formdata.append('image', image[0]);
      }      
     
      $.ajax({
        type: "POST",
        url: "actions/userProfile.php",
        enctype: 'multipart/form-data',
        processData: false,
        contentType: false,
        cache: false,
        data: formdata,
        success: function (data) {
          if (data.trim() == 'true'){
            toastr.success('User Saved Successfully...!');
            setTimeout(function (){
              location.href = "manageUserProfiles.php";
            },1000);
          }
          else{
            toastr.error('Data not Saved. Please Try Later');
          }
        }
      });
    }
  });
});