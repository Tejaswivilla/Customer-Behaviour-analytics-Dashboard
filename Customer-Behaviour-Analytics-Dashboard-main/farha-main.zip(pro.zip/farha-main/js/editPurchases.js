$(function() {
  $("form[name='editPurchasesForm']").validate({
   
    rules: {         
      cust_id      : "required",
      product_catg : "required",
      product      : "required",
      date         : "required",
      price        : "required",
    },

    messages: {         
      cust_id      : "Please Select Customer Name",
      product_catg : "Please Select Product Category",
      product      : "Please Enter Product Name",
      date         : "Please Select Date",
      price        : "Please Enter Price",
    },
    
    submitHandler: function(form) {
      
      let formdata = new FormData();
      let x = $('#editPurchasesForm').serializeArray();
      $.each(x, function(i, field){
        formdata.append(field.name,field.value);
      });
      formdata.append('action' , 'update');       
     
      $.ajax({
        type: "POST",
        url: "actions/purchases.php",
        enctype: 'multipart/form-data',
        processData: false,
        contentType: false,
        cache: false,
        data: formdata,
        success: function (data) {
          if (data.trim() == 'true'){
            toastr.success('Updated Successfully...!');
            setTimeout(function (){
              location.href = "managePurchases.php";
            },1000);
          }
          else{
            toastr.error('Data not Updated..!');
          }
        }
      });
    }
  });
});